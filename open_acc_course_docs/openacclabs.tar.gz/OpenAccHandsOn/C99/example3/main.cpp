#include <cstdio>
#include <cstdlib>
#include <fstream>
using namespace std;

const unsigned int WIDTH=16384;
const unsigned int HEIGHT=16384;
const unsigned int MAX_ITERS=100;
const unsigned int MAX_COLOR=255;
const double xmin=-1.7;
const double xmax=.5;
const double ymin=-1.2;
const double ymax=1.2;
const double dx=(xmax-xmin)/WIDTH;
const double dy=(ymax-ymin)/HEIGHT;

unsigned char mandlebrot(int Px, int Py) {
  double x0=xmin+Px*dx;
  double y0=ymin+Py*dy;
  double x=0.0;
  double y=0.0;
  int i;
  for(i=0;x*x+y*y<4.0 && i<MAX_ITERS;i++) {
    double xtemp=x*x-y*y+x0;
    y=2*x*y+y0;
    x=xtemp;
  }
  return (double)MAX_COLOR*i/MAX_ITERS;
}

int main() {
  
  size_t bytes=WIDTH*HEIGHT*sizeof(unsigned int);
  unsigned char *image=(unsigned char*)malloc(bytes);
  FILE *fp=fopen("image.pgm","wb");
  fprintf(fp,"P5\n%s\n%d %d\n%d\n","#comment",WIDTH,HEIGHT,MAX_COLOR);

  for(int y=0;y<HEIGHT;y++) {
    for(int x=0;x<WIDTH;x++) {
      image[y*WIDTH+x]=mandlebrot(x,y);
    }
  }
  
  fwrite(image,sizeof(unsigned char),WIDTH*HEIGHT,fp);
  fclose(fp);
  free(image);
  return 0;
}
